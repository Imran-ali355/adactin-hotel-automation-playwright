import { test } from '@playwright/test';

export async function attachStepScreenshot(page, stepName) {
    try {
        await test.info().attach(stepName, {
            body: await page.screenshot({
                fullPage: true,
                timeout: 15000
            }),
            contentType: 'image/png',
        });
    } catch (error) {
        console.warn(`Screenshot failed for "${stepName}":`, error.message);
    }
}